# Find-weather-of-given-city
Create a robot which finds the weather of a specific city using Google.

Create a robot which finds the weather of a specific city using Google. The city of interest is introduced by user.Done
